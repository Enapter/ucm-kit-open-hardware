ENP-KIT-RL1 board project.
The board for demonstrating the capabilities of the Enapter software, implements 1 channel normally open relay.

You also need module:
ESP32-DevKitC-32D and micro USB - USB cable

The board can be placed in an box such as:
https://www.budind.com/product/general-use-boxes/utilibox-style-j-series-utility-boxes/cu-1941-mb

Be careful these components are not in the BOM.
